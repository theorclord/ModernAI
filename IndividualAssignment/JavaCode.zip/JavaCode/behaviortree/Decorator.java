package behaviortree;

public abstract class Decorator extends Node {
	public Node child;
}
