package behaviortree;

public abstract class Node {
	public abstract BehaviorTree.Status run();
}
